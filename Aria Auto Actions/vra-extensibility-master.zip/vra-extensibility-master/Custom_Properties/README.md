# Custom properties

Used in blueprint, for different extensibility actions.
May be a requirement,m in some of the actions in this repo.