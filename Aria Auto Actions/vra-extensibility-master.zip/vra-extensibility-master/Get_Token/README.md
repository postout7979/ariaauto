# Get Token

A simple reusable function, to get a bearer token, from VRA Cloud,
to use with other api functions.
