# Slack Notification

Get a notification on Slack, after each VM deployment, with Requester, Image, Name and IP, by using a ABX action.

Reguires a Slack webhook url under Inputs called "webhook_url" 