# Postman

Postman files, to test the api against a PHPipam installatin.
