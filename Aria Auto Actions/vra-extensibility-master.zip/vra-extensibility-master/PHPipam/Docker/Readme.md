# Docker

Docker-compose file, to run PHPipam.

Note this is modified, so it's possible to edit the configuration files, to allow unsecure access to PHPipam, for testing purpose.

This docker-compose image, is not sutable for production use.

