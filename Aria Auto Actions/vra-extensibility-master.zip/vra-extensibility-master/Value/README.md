# CMPValue

Can be found here : http://value.cmplab.dk
(Note the website can take up to 30 seconds to load)

The purpose is to show, the value of doing automation, by calculating time saved, for each VM deployment. 
All info, and code, can be found in the Github repo located here : https://github.com/rhjensen79/cmpvalue
