# Demo Enviroment On Demnand

This folder contains the Lambda Python code, used in the demo here :
https://www.youtube.com/watch?v=rCI3CJlnMRc

Described in the Blog post here : https://www.robert-jensen.dk/2020/06/demo-enviroment-on-demand.html
