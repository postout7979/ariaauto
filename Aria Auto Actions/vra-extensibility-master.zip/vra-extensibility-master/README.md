# VMware vRealize Automation Extensibility

A collection of Scripts, workflows etc. that i use, to extend VMware vRealize Automation
Feel free to use, but note that they are ment for inspiration, and test, and may not be production ready. 

## Issues
If you experience any problems with the code here, feel free to create and issue in github. Then I will try my best to help. 

### Everything here, can also be found on code.vmware.com in the Sample Exchange. 

### If you create something cool or usefull, then remember to share

If you have good ideas for new usecases, please let me know. 

/Robert
@rhjensen
